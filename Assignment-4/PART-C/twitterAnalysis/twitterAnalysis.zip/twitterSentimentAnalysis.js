
const aws = require('aws-sdk');

var comprehend = new aws.Comprehend();

const s3Client = new aws.S3({
    accessKeyId:"ASIAVJDCQO5AWDOLDDMT",
    secretAccessKey: "gs85m22lZqF+oTKNPv/5iZK1I4n+UpswASIER/eK",
    sessionToken: "FwoGZXIvYXdzEK///////////wEaDCNaSB6nl+v0JuDwcSK/AdwftnlEOp1mThwQgfuqVgWI/KfnFjBLEM068CxDKUSLMY+jnB5iONqcb6DfU0PJBDpbcM92OtjZ4kW4UJLYks4NOx2gbTV6JFBnnzk9Ue9h8/08xW68XTK09p+9/zictQhPJCGTrxtAr2vn5QaOfIm88eKYX17oYVn3MCBYJROxRWXfxQqqK2U9OI6ZMh9wr9ghwcZm0T20mTCDIvBGRF0J+u3dw7i3t55PudDYyWSCjHGwBSF7XRn7LFyEHkiiKKfBn4cGMi0wZ36JpA1+1WHMiWnEyMUDGvzwhp4Vnkoh2We2U3mFDsLon1ZIznxoidtIjKM="
    });

exports.handler = async (event,context) => {
   
   console.log("Sentiment Analysis Started.");
   
   var bucketName = event.Records[0].s3.bucket.name;
   
   var fileName = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, ' '));
   
   var s3Params = {
        Bucket:bucketName,
        Key: fileName
    };

    console.log(bucketName+" "+fileName); 

    var languages = ["en","es","fr","de","it","pt","ar","hi","ja","ko","zh","zh-TW"];
   
    var sentiments = [];
   
/*    return await new Promise((resolve, reject) => {
    */
    var data = await s3Client.getObject(s3Params).promise();
    
    var tweetData = data.Body.toString('utf-8');

    var tweetArray = [];
    var tempArray = [];

    var tempArray = tweetData.split("\n");
    var tweet;
            
    for(var line of tempArray){
        if(line.length < 1){
            tweet = tweet.replace(/(\r\n|\n|\r)/gm, "");
            tweetArray.push(tweet);
            tweet='';
        } else {
            tweet += line;
        }
    }
   
    for(var tweet of tweetArray)
    {
        var bytes = Buffer.byteLength(tweet, "utf-8");
        if(bytes < 5000){
            getsentiment(tweet).then((value) => console.log(value));
        }
    }   

   
    async function getsentiment(tweet) {

            if(tweet.length > 0){
                    var lanParam = {
                    Text: tweet,
                };
                
              var language = comprehend.detectDominantLanguage(lanParam);
             
              console.log(language.Languages[0].LanguageCode);
             
              if(languages.includes(language))
              {
                var params = {
                    LanguageCode: 'en',
                    Text: tweet
                };
                data = comprehend.detectSentiment(params); 
                }
        }
        /*
        console.log(data);*/
        
    }
}
